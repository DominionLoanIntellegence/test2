import { StreamingTextResponse, LangChainStream } from 'ai'
import { ChatOpenAI } from 'langchain/chat_models/openai'
import { ConversationalRetrievalQAChain } from 'langchain/chains'
import { HNSWLib } from 'langchain/vectorstores/hnswlib'
import { OpenAIEmbeddings } from 'langchain/embeddings/openai'
import { RecursiveCharacterTextSplitter } from 'langchain/text_splitter'
import * as fs from 'fs'
import * as path from 'path'

// Initialize the vector store (this should be done once and reused)
const initVectorStore = async () => {
  const text = fs.readFileSync(path.join(process.cwd(), 'loan_guidelines.txt'), 'utf8')
  const textSplitter = new RecursiveCharacterTextSplitter({ chunkSize: 1000 })
  const docs = await textSplitter.createDocuments([text])
  return await HNSWLib.fromDocuments(docs, new OpenAIEmbeddings())
}

let vectorStore: HNSWLib

export async function POST(req: Request) {
  const { messages } = await req.json()
  const { stream, handlers } = LangChainStream()

  if (!vectorStore) {
    vectorStore = await initVectorStore()
  }

  const model = new ChatOpenAI({
    modelName: 'gpt-4',
    streaming: true,
  })

  const chain = ConversationalRetrievalQAChain.fromLLM(
    model,
    vectorStore.asRetriever(),
    {
      returnSourceDocuments: true,
    }
  )

  chain.call(
    {
      question: messages[messages.length - 1].content,
      chat_history: messages.slice(0, -1).map((m: any) => m.content),
    },
    [handlers]
  )

  return new StreamingTextResponse(stream)
}

