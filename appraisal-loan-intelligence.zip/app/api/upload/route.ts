import { NextRequest, NextResponse } from 'next/server'

const AZURE_ENDPOINT = process.env.AZURE_ENDPOINT
const AZURE_API_KEY = process.env.AZURE_API_KEY
const MODEL_ID = process.env.AZURE_MODEL_ID

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get('file') as File
    
    if (!file) {
      return NextResponse.json(
        { error: 'No file uploaded' },
        { status: 400 }
      )
    }

    // Convert file to buffer for Azure API
    const buffer = Buffer.from(await file.arrayBuffer())

    const response = await fetch(
      `${AZURE_ENDPOINT}/formrecognizer/documentModels/${MODEL_ID}:analyze`,
      {
        method: 'POST',
        headers: {
          'Ocp-Apim-Subscription-Key': AZURE_API_KEY!,
          'Content-Type': 'application/pdf'
        },
        body: buffer
      }
    )

    if (!response.ok) {
      throw new Error(`Azure API error: ${response.statusText}`)
    }

    const result = await response.json()

    return NextResponse.json({ result })
  } catch (error) {
    console.error('Upload error:', error)
    return NextResponse.json(
      { error: 'Error processing file' },
      { status: 500 }
    )
  }
}

