import Image from 'next/image'
import FileUpload from './components/FileUpload'
import ChatWidget from './components/ChatWidget'

export default function Home() {
  return (
    <main className="container mt-5">
      <div className="image-section">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Capture3-removebg-preview-VYu42IWJXgvDRwhN7tpF4QLf8MY7eR.png"
          alt="Dominion Loan Intelligence Logo"
          width={300}
          height={300}
          className="logo-image"
          priority
          style={{
            maxWidth: '100%',
            height: 'auto',
            objectFit: 'contain',
            background: 'transparent'
          }}
        />
      </div>

      <div className="row justify-content-center mt-5">
        <div className="col-md-8">
          <FileUpload />
        </div>
      </div>

      <ChatWidget />

      <footer className="footer">
        <p>
          &copy; 2025 Appraisal Loan Intelligence. All Rights Reserved. |{' '}
          <a href="https://www.example.com/privacy" target="_blank" rel="noopener noreferrer" className="text-white underline">
            Privacy Policy
          </a>
        </p>
      </footer>
    </main>
  )
}

