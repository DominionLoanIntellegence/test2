'use client'

import { useState } from 'react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Upload, Loader2 } from 'lucide-react'

export default function FileUpload() {
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([])
  const [isUploading, setIsUploading] = useState(false)
  const [results, setResults] = useState<any>(null)

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) {
      const files = Array.from(event.target.files)
      setUploadedFiles(files)
      
      // Automatically start upload when files are selected
      await handleUpload(files)
    }
  }

  const handleUpload = async (files: File[]) => {
    setIsUploading(true)
    try {
      const formData = new FormData()
      files.forEach(file => {
        formData.append('file', file)
      })

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      })

      if (!response.ok) {
        throw new Error('Upload failed')
      }

      const data = await response.json()
      setResults(data.result)
    } catch (error) {
      console.error('Upload error:', error)
    } finally {
      setIsUploading(false)
    }
  }

  return (
    <Card className="card-custom">
      <div 
        className="drag-drop"
        onDragOver={(e) => e.preventDefault()}
        onDrop={async (e) => {
          e.preventDefault()
          const files = Array.from(e.dataTransfer.files)
          setUploadedFiles(files)
          await handleUpload(files)
        }}
      >
        <Upload className="w-12 h-12 mb-4 text-primary" />
        <p className="mb-2">Drag and Drop Files Here</p>
        <p>or</p>
        <Button 
          variant="default" 
          className="mt-3"
          disabled={isUploading}
        >
          {isUploading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Uploading...
            </>
          ) : (
            'Browse'
          )}
        </Button>
        <input
          type="file"
          name="files"
          className="hidden"
          accept=".pdf"
          multiple
          onChange={handleFileChange}
        />
      </div>

      <div className="upload-list mt-4">
        <h5>Uploaded Files</h5>
        <div className="list-group">
          {uploadedFiles.map((file, index) => (
            <div key={index} className="upload-list-item">
              <span>{file.name} ({(file.size / 1024).toFixed(2)} KB)</span>
              <span className="badge bg-success">
                {isUploading ? 'Uploading...' : 'Uploaded'}
              </span>
            </div>
          ))}
        </div>

        {results && (
          <div className="mt-4">
            <h5>Analysis Results</h5>
            <pre className="bg-muted p-4 rounded-lg overflow-auto">
              {JSON.stringify(results, null, 2)}
            </pre>
          </div>
        )}
      </div>
    </Card>
  )
}

