'use client'

import { useState } from 'react'
import { MessageCircle } from 'lucide-react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import Image from 'next/image'
import { ChatBot } from './ChatBot'

export default function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="chat-widget-button flex items-center justify-center"
        aria-label="Open chat"
      >
        <MessageCircle className="h-6 w-6 text-white" />
        <span className="chat-tooltip">Chat with Loan Rules Expert</span>
      </button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-[500px] h-[600px] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <div className="relative h-10 w-10">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Capture3-removebg-preview-VYu42IWJXgvDRwhN7tpF4QLf8MY7eR.png"
                  alt="Loan Expert Avatar"
                  fill
                  className="rounded-full object-cover"
                />
              </div>
              <span>Chat with Loan Rules Expert</span>
            </DialogTitle>
          </DialogHeader>
          <div className="flex-grow overflow-hidden">
            <ChatBot />
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}

